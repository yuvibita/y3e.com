import React from 'react';
import { Trophy, Brain, Target, Zap } from 'lucide-react';

export function GameFeatures() {
  const features = [
    {
      icon: <Trophy className="w-8 h-8" />,
      title: "Achievement System",
      description: "Earn badges and level up as you master new coding concepts"
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Skill Trees",
      description: "Customize your learning path with branching skill trees"
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: "Daily Challenges",
      description: "Keep your skills sharp with daily coding puzzles"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Power-Ups",
      description: "Unlock special tools and hints as you progress"
    }
  ];

  return (
    <div className="bg-gray-800 py-24">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-white text-center mb-16">
          Level Up Your Skills
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-gray-700 p-6 rounded-xl hover:bg-gray-600 transition-all transform hover:-translate-y-2"
            >
              <div className="text-purple-400 mb-4">{feature.icon}</div>
              <h3 className="text-white text-xl font-semibold mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}