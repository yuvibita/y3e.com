import React from 'react';
import { Code2, Terminal, Wand2 } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-gray-900 min-h-screen">
      {/* Animated background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
      
      <div className="relative container mx-auto px-4 py-24">
        <div className="text-center">
          <div className="flex justify-center mb-8">
            <Code2 className="w-20 h-20 text-purple-500 animate-pulse" />
          </div>
          <h1 className="text-6xl font-bold text-white mb-6 animate-fade-in">
            Code<span className="text-purple-500">Kat</span>
          </h1>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Level up your coding journey with our interactive learning platform
          </p>
          
          <div className="flex justify-center gap-8 mb-16">
            <FeatureCard
              icon={<Terminal className="w-8 h-8" />}
              title="Interactive Tutorials"
              description="Learn by doing with our hands-on coding challenges"
            />
            <FeatureCard
              icon={<Wand2 className="w-8 h-8" />}
              title="AI-Powered Help"
              description="Get instant feedback and suggestions as you code"
            />
          </div>
          
          <button className="bg-purple-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-purple-700 transition-all transform hover:scale-105">
            Start Coding Now
          </button>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-gray-800 p-6 rounded-xl hover:bg-gray-700 transition-all transform hover:-translate-y-1 cursor-pointer">
      <div className="text-purple-500 mb-4">{icon}</div>
      <h3 className="text-white text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
}